// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        //'password': 'FundableD0ubles', // Password para devkinnil
        'password': 'Fundabled0ubles', // Password para ezairkinnil
        'connectionLimit': 5000, // TODO: hacer pruebas para ver con cual funciona bien
        'database': 'kinnil'
    },
    'users_table': 'users',
    'database': 'kinnil'
};

